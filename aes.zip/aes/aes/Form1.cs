﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.IO;

namespace aes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string en = encryptostring("1234567890123456", textBox1.Text);
            Clipboard.SetText(en);
            MessageBox.Show(en);
        }
        public static string encryptostring(string key,string plaintext)
        {
            byte[] iv = new byte[16];//16 bytes means key of 16 letter
            using(Aes aes=Aes.Create())
            {
                aes.Key = Encoding.UTF8.GetBytes(key);
                aes.IV = iv;
                ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV);
                var ms = new MemoryStream();
                var cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write);
                byte[] input = Encoding.UTF8.GetBytes(plaintext);
                cs.Write(input, 0, input.Length);
                cs.FlushFinalBlock();
                return Convert.ToBase64String(ms.ToArray());
            }
        }
        public static string Decryptostring(string key, string ciphertext)
        {
            byte[] iv = new byte[16];
            byte[] buffer = Convert.FromBase64String(ciphertext);
            using (Aes aes = Aes.Create())
            {
                aes.Key = Encoding.UTF8.GetBytes(key);
                aes.IV = iv;
                ICryptoTransform Decryptor = aes.CreateDecryptor(aes.Key, aes.IV);
                var ms = new MemoryStream();
                var cs = new CryptoStream(ms, Decryptor, CryptoStreamMode.Write);
                
                cs.Write(buffer, 0, buffer.Length);
                cs.FlushFinalBlock();
                return Encoding.UTF8.GetString(ms.ToArray());
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string de = Decryptostring("1234567890123456", textBox2.Text);
            MessageBox.Show(de);
        }
    }
}